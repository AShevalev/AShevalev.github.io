Open INSTRUCTIONS.md first. Copy files from landing/, dashboard/, and trade/ as mapped there.
