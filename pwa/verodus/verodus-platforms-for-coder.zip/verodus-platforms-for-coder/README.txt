Open INSTRUCTIONS.md first. Copy landing/ and dashboard/ as mapped there.
