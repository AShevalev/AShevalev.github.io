/**
 * Copy to dashboard Next.js:
 *   app/p5/[accountId]/page.jsx
 *
 * Next 15+: const { accountId } = await params;
 */
import PlatformFrame from "@/components/PlatformFrame";

export default function Platform5Page({ params }) {
  const accountId = params?.accountId;
  return <PlatformFrame kind="p5" accountId={accountId} />;
}
