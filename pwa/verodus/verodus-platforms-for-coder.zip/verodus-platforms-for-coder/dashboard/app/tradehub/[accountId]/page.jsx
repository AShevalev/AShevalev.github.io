/**
 * Copy to dashboard Next.js:
 *   app/tradehub/[accountId]/page.jsx
 *
 * Next 15+: const { accountId } = await params;
 */
import PlatformFrame from "@/components/PlatformFrame";

export default function TradehubPage({ params }) {
  const accountId = params?.accountId;
  return <PlatformFrame kind="tradehub" accountId={accountId} />;
}
