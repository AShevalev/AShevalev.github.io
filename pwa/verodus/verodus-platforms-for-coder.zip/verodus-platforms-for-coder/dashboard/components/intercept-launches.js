/**
 * Drop this on dashboard.verodus.com.
 *
 * Top-level installed windows: rewrite TradeHub / P5 to same-origin paths.
 * Already inside an iframe: do nothing so that frame can go to trade.verodus.com
 * without nesting.
 */
import { isEmbedded } from "./lock-origin.js";
import { toInAppUrl } from "./same-origin.js";

if (!isEmbedded()) {
  document.addEventListener(
    "click",
    (event) => {
      const link = event.target.closest && event.target.closest("a[href]");
      if (!link) return;
      const next = toInAppUrl(link.href, window.location.origin);
      if (!next || next === link.href) return;
      event.preventDefault();
      window.location.assign(next);
    },
    true
  );

  try {
    const originalOpen = window.open.bind(window);
    window.open = (url, target, features) => {
      if (url) {
        const next = toInAppUrl(String(url), window.location.origin);
        if (next) {
          window.location.assign(next);
          return window;
        }
      }
      return originalOpen(url, target, features);
    };
  } catch {
    // window.open may be non-writable in some WebViews.
  }
}
